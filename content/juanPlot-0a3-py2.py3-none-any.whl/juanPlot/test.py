from juanPlot.__init__ import *

def func_test():
    print("Successfully Imported test.py file")